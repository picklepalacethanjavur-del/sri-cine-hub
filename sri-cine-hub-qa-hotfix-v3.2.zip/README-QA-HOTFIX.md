# Sri Cine Hub V3.2 QA Hotfix

QA fixes included:
- Public quote submission now uses secure `submit_quote_request()` RPC instead of direct table insert + select.
- Prevents invalid/past date submissions at both UI and database layers.
- Admin pages now require an active `admin` or `staff` role, not merely any authenticated account.
- Staff pages automatically sync past-due checked-out bookings to `overdue`.
- Dashboard now shows an Overdue metric.
- Adds visible database error handling to bookings/calendar/inventory pages.

Database migrations for the quote RPC, availability validation, and overdue sync have ALREADY been applied to the live Sri Cine Hub Supabase project.

Upload these files into the same paths in the ROOT of the GitHub repository, replacing existing files. Vercel should redeploy automatically.
