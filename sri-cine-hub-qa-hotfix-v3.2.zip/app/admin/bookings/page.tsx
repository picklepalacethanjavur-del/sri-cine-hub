import { AdminNav } from "@/components/AdminNav";
import { requireStaff } from "@/lib/auth";

export default async function Bookings(){
  const {supabase}=await requireStaff();
  await supabase.rpc("sync_overdue_bookings");
  const {data,error}=await supabase
    .from("bookings")
    .select("*,customers(name,company_name),booking_cameras(camera_id,cameras(camera_code,name))")
    .order("start_at",{ascending:false});

  return <section className="adminShell">
    <div className="eyebrow">LIVE BOOKINGS</div><h1>Reservations & rentals</h1><AdminNav/>
    <div className="adminPanel">
      {error&&<div className="errorBox">{error.message}</div>}
      {(data||[]).length?(data||[]).map((b:any)=><div className="bookingRow tall" key={b.id}>
        <div>
          <b>{b.booking_code} · {b.production_name||b.customers?.company_name||b.customers?.name||"Client"}</b>
          <span>{b.project_name||"Project"} · {new Date(b.start_at).toLocaleString("en-IN")} → {new Date(b.end_at).toLocaleString("en-IN")}</span>
          <span>{(b.booking_cameras||[]).map((x:any)=>x.cameras?.camera_code+" "+x.cameras?.name).filter(Boolean).join(", ")}</span>
        </div>
        <div className="bookingFinance">
          <em className={`status ${b.status}`}>{b.status.replaceAll("_"," ")}</em>
          <b>₹{Number(b.quoted_total_inr||0).toLocaleString("en-IN")}</b>
        </div>
      </div>):!error&&<p>No bookings yet.</p>}
    </div>
  </section>;
}
