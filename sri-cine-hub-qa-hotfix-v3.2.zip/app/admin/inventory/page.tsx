import { AdminNav } from "@/components/AdminNav";
import { requireStaff } from "@/lib/auth";

export default async function Inventory(){
  const {supabase}=await requireStaff();
  const [{data:cameras,error:cameraError},{data:accessories,error:accessoryError}]=await Promise.all([
    supabase.from("cameras").select("*").order("camera_code"),
    supabase.from("accessories").select("*").order("accessory_code")
  ]);

  return <section className="adminShell">
    <div className="eyebrow">LIVE INVENTORY</div><h1>Serialized equipment</h1><AdminNav/>
    <div className="adminPanel"><h2>Cameras</h2>
      {cameraError&&<div className="errorBox">{cameraError.message}</div>}
      {(cameras||[]).map(c=><div className="bookingRow" key={c.id}>
        <div><b>{c.camera_code} · {c.name}</b><span>{c.manufacturer||""} {c.model||""} · Serial {c.serial_number||"not entered"} · {c.current_hours||0}h</span></div>
        <em className={`status ${c.status}`}>{c.status}</em>
      </div>)}
    </div>
    <div className="adminPanel"><h2>Accessories</h2>
      {accessoryError&&<div className="errorBox">{accessoryError.message}</div>}
      {(accessories||[]).length?(accessories||[]).map(a=><div className="bookingRow" key={a.id}>
        <div><b>{a.accessory_code} · {a.name}</b><span>{a.category||"Accessory"} · {a.location||"Chennai"}</span></div>
        <em className={`status ${a.status}`}>{a.status}</em>
      </div>):!accessoryError&&<p>No serialized accessories entered yet.</p>}
    </div>
  </section>;
}
