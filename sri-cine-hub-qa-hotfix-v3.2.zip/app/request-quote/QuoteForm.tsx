"use client";
import { useMemo, useState } from "react";
import { createClient } from "@/lib/supabase/client";

type Camera = {
  camera_id:string;
  camera_code:string;
  name:string;
  manufacturer:string|null;
  model:string|null;
  image_url:string|null;
  available:boolean;
};

function localDateTimeMin(){
  const d=new Date();
  d.setMinutes(d.getMinutes()-d.getTimezoneOffset());
  return d.toISOString().slice(0,16);
}

export default function QuoteForm(){
  const [cameras,setCameras]=useState<Camera[]>([]);
  const [selected,setSelected]=useState<string[]>([]);
  const [loading,setLoading]=useState(false);
  const [message,setMessage]=useState("");
  const [start,setStart]=useState("");
  const [end,setEnd]=useState("");
  const minDate=useMemo(()=>localDateTimeMin(),[]);
  const supabase=createClient();

  async function availability(nextStart=start,nextEnd=end){
    if(!nextStart||!nextEnd){
      setCameras([]);
      return;
    }
    const startDate=new Date(nextStart);
    const endDate=new Date(nextEnd);
    if(endDate<=startDate){
      setCameras([]);
      setSelected([]);
      setMessage("Return date/time must be after start date/time.");
      return;
    }
    setLoading(true);
    setMessage("");
    const {data,error}=await supabase.rpc("public_camera_availability",{
      p_start:startDate.toISOString(),
      p_end:endDate.toISOString()
    });
    if(error) setMessage(error.message);
    else {
      setCameras((data||[]) as Camera[]);
      setSelected([]);
    }
    setLoading(false);
  }

  async function submit(e:React.FormEvent<HTMLFormElement>){
    e.preventDefault();
    const startDate=new Date(start);
    const endDate=new Date(end);
    if(!start||!end||endDate<=startDate){
      setMessage("Return date/time must be after start date/time.");
      return;
    }

    setLoading(true);
    setMessage("");
    const f=new FormData(e.currentTarget);

    const {data,error}=await supabase.rpc("submit_quote_request",{
      p_name:String(f.get("name")||""),
      p_company_name:String(f.get("client")||""),
      p_phone:String(f.get("phone")||""),
      p_project_name:String(f.get("project")||""),
      p_start:startDate.toISOString(),
      p_end:endDate.toISOString(),
      p_requested_camera_ids:selected,
      p_notes:String(f.get("notes")||"")
    });

    if(error){
      setMessage(error.message);
    } else {
      setMessage(`Request ${data} received. Sri Cine Hub will confirm availability and pricing.`);
      e.currentTarget.reset();
      setSelected([]);
      setCameras([]);
      setStart("");
      setEnd("");
    }
    setLoading(false);
  }

  return <form className="quoteForm" onSubmit={submit}>
    <div className="formGrid">
      <label>Production / Client *<input required name="client" maxLength={120}/></label>
      <label>Project *<input required name="project" maxLength={160}/></label>
    </div>

    <div className="formGrid">
      <label>Start date & time *
        <input required type="datetime-local" min={minDate} value={start}
          onChange={e=>{setStart(e.target.value);availability(e.target.value,end)}}/>
      </label>
      <label>Return date & time *
        <input required type="datetime-local" min={start||minDate} value={end}
          onChange={e=>{setEnd(e.target.value);availability(start,e.target.value)}}/>
      </label>
    </div>

    <div className="availabilityBox">
      <b>Camera availability</b>
      {loading&&<p>Checking…</p>}
      {!loading&&cameras.length===0&&<p className="formNote">Choose valid start and return dates to check serialized camera availability.</p>}
      {cameras.map(c=><label key={c.camera_id} className={`availabilityRow ${c.available?"available":"unavailable"}`}>
        <input type="checkbox" disabled={!c.available} checked={selected.includes(c.camera_id)}
          onChange={e=>setSelected(e.target.checked?[...selected,c.camera_id]:selected.filter(x=>x!==c.camera_id))}/>
        <span><strong>{c.camera_code} · {c.name}</strong><small>{c.available?"Available":"Unavailable for selected dates"}</small></span>
      </label>)}
    </div>

    <div className="formGrid">
      <label>Contact name *<input required name="name" minLength={2} maxLength={120}/></label>
      <label>Phone / WhatsApp *<input required name="phone" minLength={6} maxLength={30} inputMode="tel"/></label>
    </div>

    <label>Additional package requirements
      <textarea name="notes" rows={5} maxLength={2000} placeholder="Lenses, lights, grip, crew, transport, genset, post-production…"/>
    </label>

    <button className="button gold" disabled={loading} type="submit">
      {loading?"Submitting…":"Request availability & quote"}
    </button>
    {message&&<div className={message.startsWith("Request")?"successBox":"errorBox"}>{message}</div>}
    <p className="formNote">No payment is collected here. Staff reviews and confirms the reservation.</p>
  </form>;
}
